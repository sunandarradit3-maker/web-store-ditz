// server.js - Backend API untuk DiTz Store
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = 'ditzstore-secret-key-2024';

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// Database Setup
const db = new sqlite3.Database('./ditzstore.db', (err) => {
    if (err) {
        console.error('Error opening database:', err);
    } else {
        console.log('Connected to SQLite database');
        initializeDatabase();
    }
});

// Initialize Database Tables
function initializeDatabase() {
    // Users Table
    db.run(`CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT DEFAULT 'customer',
        phone TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // Products Table
    db.run(`CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        category TEXT NOT NULL,
        price INTEGER NOT NULL,
        stock INTEGER DEFAULT 999,
        description TEXT,
        image TEXT,
        badge TEXT,
        status TEXT DEFAULT 'active',
        sales INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // Orders Table
    db.run(`CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id TEXT UNIQUE NOT NULL,
        user_id INTEGER,
        customer_name TEXT NOT NULL,
        customer_email TEXT,
        customer_phone TEXT NOT NULL,
        products TEXT NOT NULL,
        total_amount INTEGER NOT NULL,
        payment_method TEXT NOT NULL,
        status TEXT DEFAULT 'pending',
        notes TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )`);

    // Services Table
    db.run(`CREATE TABLE IF NOT EXISTS services (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        game TEXT NOT NULL,
        price_min INTEGER NOT NULL,
        price_max INTEGER NOT NULL,
        description TEXT,
        features TEXT,
        status TEXT DEFAULT 'active',
        orders_count INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // Reviews Table
    db.run(`CREATE TABLE IF NOT EXISTS reviews (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id TEXT NOT NULL,
        user_id INTEGER,
        rating INTEGER NOT NULL,
        comment TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )`);

    // Transactions Table
    db.run(`CREATE TABLE IF NOT EXISTS transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id TEXT NOT NULL,
        amount INTEGER NOT NULL,
        payment_method TEXT NOT NULL,
        status TEXT DEFAULT 'pending',
        payment_proof TEXT,
        processed_at DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // Create default admin user
    const adminPassword = bcrypt.hashSync('admin123', 10);
    db.run(`INSERT OR IGNORE INTO users (username, email, password, role, phone) 
            VALUES (?, ?, ?, ?, ?)`,
        ['admin', 'admin@ditzstore.com', adminPassword, 'admin', '081234567890']
    );

    console.log('Database initialized successfully');
}

// Authentication Middleware
function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ error: 'Access token required' });
    }

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) {
            return res.status(403).json({ error: 'Invalid token' });
        }
        req.user = user;
        next();
    });
}

// Admin Middleware
function isAdmin(req, res, next) {
    if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Admin access required' });
    }
    next();
}

// ==================== AUTH ROUTES ====================

// Register
app.post('/api/auth/register', async (req, res) => {
    const { username, email, password, phone } = req.body;

    if (!username || !email || !password) {
        return res.status(400).json({ error: 'All fields required' });
    }

    const hashedPassword = bcrypt.hashSync(password, 10);

    db.run(
        `INSERT INTO users (username, email, password, phone) VALUES (?, ?, ?, ?)`,
        [username, email, hashedPassword, phone],
        function(err) {
            if (err) {
                return res.status(400).json({ error: 'User already exists' });
            }
            res.json({ 
                message: 'User registered successfully',
                userId: this.lastID
            });
        }
    );
});

// Login
app.post('/api/auth/login', (req, res) => {
    const { email, password } = req.body;

    db.get(`SELECT * FROM users WHERE email = ?`, [email], (err, user) => {
        if (err || !user) {
            return res.status(400).json({ error: 'Invalid credentials' });
        }

        if (!bcrypt.compareSync(password, user.password)) {
            return res.status(400).json({ error: 'Invalid credentials' });
        }

        const token = jwt.sign(
            { id: user.id, email: user.email, role: user.role },
            JWT_SECRET,
            { expiresIn: '7d' }
        );

        res.json({
            token,
            user: {
                id: user.id,
                username: user.username,
                email: user.email,
                role: user.role
            }
        });
    });
});

// ==================== PRODUCT ROUTES ====================

// Get all products
app.get('/api/products', (req, res) => {
    const { category, search, limit, offset } = req.query;
    
    let query = 'SELECT * FROM products WHERE status = "active"';
    const params = [];

    if (category) {
        query += ' AND category = ?';
        params.push(category);
    }

    if (search) {
        query += ' AND (name LIKE ? OR description LIKE ?)';
        params.push(`%${search}%`, `%${search}%`);
    }

    query += ' ORDER BY sales DESC';

    if (limit) {
        query += ' LIMIT ?';
        params.push(parseInt(limit));
    }

    if (offset) {
        query += ' OFFSET ?';
        params.push(parseInt(offset));
    }

    db.all(query, params, (err, products) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(products);
    });
});

// Get single product
app.get('/api/products/:id', (req, res) => {
    db.get('SELECT * FROM products WHERE id = ?', [req.params.id], (err, product) => {
        if (err || !product) {
            return res.status(404).json({ error: 'Product not found' });
        }
        res.json(product);
    });
});

// Create product (Admin only)
app.post('/api/products', authenticateToken, isAdmin, (req, res) => {
    const { name, category, price, stock, description, image, badge } = req.body;

    db.run(
        `INSERT INTO products (name, category, price, stock, description, image, badge)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [name, category, price, stock || 999, description, image, badge],
        function(err) {
            if (err) {
                return res.status(500).json({ error: err.message });
            }
            res.json({ 
                message: 'Product created successfully',
                productId: this.lastID
            });
        }
    );
});

// Update product (Admin only)
app.put('/api/products/:id', authenticateToken, isAdmin, (req, res) => {
    const { name, category, price, stock, description, image, badge, status } = req.body;

    db.run(
        `UPDATE products 
         SET name = ?, category = ?, price = ?, stock = ?, description = ?, 
             image = ?, badge = ?, status = ?
         WHERE id = ?`,
        [name, category, price, stock, description, image, badge, status, req.params.id],
        function(err) {
            if (err) {
                return res.status(500).json({ error: err.message });
            }
            res.json({ message: 'Product updated successfully' });
        }
    );
});

// Delete product (Admin only)
app.delete('/api/products/:id', authenticateToken, isAdmin, (req, res) => {
    db.run('DELETE FROM products WHERE id = ?', [req.params.id], function(err) {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json({ message: 'Product deleted successfully' });
    });
});

// ==================== ORDER ROUTES ====================

// Create order
app.post('/api/orders', (req, res) => {
    const { customer_name, customer_email, customer_phone, products, payment_method, notes } = req.body;

    // Generate order ID
    const orderId = 'ORD-' + Date.now();
    
    // Calculate total
    const productsData = JSON.parse(products);
    const total = productsData.reduce((sum, item) => sum + (item.price * item.quantity), 0);

    db.run(
        `INSERT INTO orders (order_id, customer_name, customer_email, customer_phone, 
                            products, total_amount, payment_method, notes)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [orderId, customer_name, customer_email, customer_phone, products, total, payment_method, notes],
        function(err) {
            if (err) {
                return res.status(500).json({ error: err.message });
            }

            // Update product sales
            productsData.forEach(item => {
                db.run('UPDATE products SET sales = sales + ?, stock = stock - ? WHERE id = ?',
                    [item.quantity, item.quantity, item.id]);
            });

            res.json({ 
                message: 'Order created successfully',
                orderId: orderId,
                total: total
            });
        }
    );
});

// Get all orders (Admin only)
app.get('/api/orders', authenticateToken, isAdmin, (req, res) => {
    const { status, limit, offset } = req.query;
    
    let query = 'SELECT * FROM orders';
    const params = [];

    if (status) {
        query += ' WHERE status = ?';
        params.push(status);
    }

    query += ' ORDER BY created_at DESC';

    if (limit) {
        query += ' LIMIT ?';
        params.push(parseInt(limit));
    }

    if (offset) {
        query += ' OFFSET ?';
        params.push(parseInt(offset));
    }

    db.all(query, params, (err, orders) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(orders);
    });
});

// Get single order
app.get('/api/orders/:orderId', (req, res) => {
    db.get('SELECT * FROM orders WHERE order_id = ?', [req.params.orderId], (err, order) => {
        if (err || !order) {
            return res.status(404).json({ error: 'Order not found' });
        }
        res.json(order);
    });
});

// Update order status (Admin only)
app.put('/api/orders/:orderId/status', authenticateToken, isAdmin, (req, res) => {
    const { status } = req.body;

    db.run(
        'UPDATE orders SET status = ? WHERE order_id = ?',
        [status, req.params.orderId],
        function(err) {
            if (err) {
                return res.status(500).json({ error: err.message });
            }
            res.json({ message: 'Order status updated successfully' });
        }
    );
});

// ==================== STATISTICS ROUTES ====================

// Dashboard stats (Admin only)
app.get('/api/stats/dashboard', authenticateToken, isAdmin, (req, res) => {
    const stats = {};

    // Total revenue
    db.get('SELECT SUM(total_amount) as total FROM orders WHERE status = "completed"', 
        (err, result) => {
            stats.totalRevenue = result ? result.total || 0 : 0;

            // Total orders
            db.get('SELECT COUNT(*) as count FROM orders', (err, result) => {
                stats.totalOrders = result ? result.count : 0;

                // Total customers
                db.get('SELECT COUNT(*) as count FROM users WHERE role = "customer"', 
                    (err, result) => {
                        stats.totalCustomers = result ? result.count : 0;

                        // Total products
                        db.get('SELECT COUNT(*) as count FROM products WHERE status = "active"', 
                            (err, result) => {
                                stats.totalProducts = result ? result.count : 0;

                                res.json(stats);
                            }
                        );
                    }
                );
            });
        }
    );
});

// Sales by category
app.get('/api/stats/categories', authenticateToken, isAdmin, (req, res) => {
    db.all(
        `SELECT category, SUM(sales) as total_sales, COUNT(*) as product_count
         FROM products 
         GROUP BY category`,
        (err, results) => {
            if (err) {
                return res.status(500).json({ error: err.message });
            }
            res.json(results);
        }
    );
});

// Top selling products
app.get('/api/stats/top-products', authenticateToken, isAdmin, (req, res) => {
    const limit = req.query.limit || 10;
    
    db.all(
        `SELECT * FROM products 
         WHERE status = "active" 
         ORDER BY sales DESC 
         LIMIT ?`,
        [limit],
        (err, products) => {
            if (err) {
                return res.status(500).json({ error: err.message });
            }
            res.json(products);
        }
    );
});

// ==================== SERVICES ROUTES ====================

// Get all services
app.get('/api/services', (req, res) => {
    db.all('SELECT * FROM services WHERE status = "active"', (err, services) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(services);
    });
});

// Create service (Admin only)
app.post('/api/services', authenticateToken, isAdmin, (req, res) => {
    const { name, game, price_min, price_max, description, features } = req.body;

    db.run(
        `INSERT INTO services (name, game, price_min, price_max, description, features)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [name, game, price_min, price_max, description, JSON.stringify(features)],
        function(err) {
            if (err) {
                return res.status(500).json({ error: err.message });
            }
            res.json({ 
                message: 'Service created successfully',
                serviceId: this.lastID
            });
        }
    );
});

// ==================== WEBHOOK & PAYMENT ====================

// Payment webhook (for payment gateway integration)
app.post('/api/webhook/payment', (req, res) => {
    const { order_id, status, amount } = req.body;

    if (status === 'success') {
        db.run(
            'UPDATE orders SET status = ? WHERE order_id = ?',
            ['completed', order_id],
            (err) => {
                if (err) {
                    return res.status(500).json({ error: err.message });
                }
                
                // Send notification to customer
                console.log(`Payment successful for order ${order_id}`);
                
                res.json({ message: 'Payment processed successfully' });
            }
        );
    } else {
        res.json({ message: 'Payment status updated' });
    }
});

// ==================== ERROR HANDLING ====================

app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: 'Something went wrong!' });
});

// ==================== START SERVER ====================

app.listen(PORT, () => {
    console.log(`🚀 DiTz Store API running on http://localhost:${PORT}`);
    console.log(`📊 Admin Panel: http://localhost:${PORT}/admin.html`);
    console.log(`🛍️  Store: http://localhost:${PORT}/index.html`);
});

// Graceful shutdown
process.on('SIGINT', () => {
    db.close((err) => {
        if (err) {
            console.error(err.message);
        }
        console.log('Database connection closed.');
        process.exit(0);
    });
});
