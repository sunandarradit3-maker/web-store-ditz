# 🚀 PANDUAN INSTALASI CEPAT - DiTz Store

## ⚡ Quick Start (5 Menit)

### 1. Persiapan
```bash
# Pastikan Node.js sudah terinstall
node --version
npm --version
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Jalankan Server
```bash
npm start
```

### 4. Buka Website
- **Toko**: http://localhost:3000/index.html
- **Admin Panel**: http://localhost:3000/admin.html

### 5. Login Admin
- **Username**: admin
- **Password**: admin123

## 📦 Isi Package

### File Frontend
1. **index.html** - Halaman toko utama
2. **styles.css** - Styling toko
3. **app.js** - Logic frontend toko

### File Admin Panel
1. **admin.html** - Dashboard admin
2. **admin-styles.css** - Styling admin
3. **admin-script.js** - Logic admin panel

### File Backend
1. **server.js** - REST API server
2. **package.json** - Dependencies
3. **ditzstore.db** - Database (auto-generated)

### Dokumentasi
1. **README.md** - Dokumentasi lengkap
2. **PANDUAN_INSTALASI.md** - Panduan ini
3. **.env.example** - Template konfigurasi

## 🎯 Fitur Utama

### Toko Online
✅ Katalog produk digital lengkap
✅ Shopping cart
✅ Checkout via WhatsApp
✅ Responsive mobile-friendly
✅ Search & filter produk

### Admin Panel
✅ Dashboard dengan statistik
✅ CRUD Produk
✅ Manajemen pesanan
✅ Manajemen pelanggan
✅ Analytics dengan chart
✅ Pengaturan toko

### Backend API
✅ RESTful API
✅ Authentication & Authorization
✅ SQLite Database
✅ Payment webhook
✅ Real-time statistics

## 🛍️ Produk Yang Tersedia

### 1. Akun Premium (9 Produk)
- Netflix, Spotify, Disney+, YouTube, Canva, Viu, WeTV, iQIYI, Vidio

### 2. Script Free Fire (7 Level)
- Auto Headshot 10%, 20%, 30%, 40%, 50%, 70%, 100%

### 3. Jasa Joki (4 Game)
- Mobile Legends, Free Fire, PUBG Mobile, Brawl Stars

### 4. Top Up Game (6 Item)
- Diamond ML, Diamond FF, UC PUBG

## 🔧 Kustomisasi

### Ganti Nomor WhatsApp
Edit `app.js` line ~400:
```javascript
const whatsappNumber = '6281234567890'; // Ganti nomor Anda
```

### Ganti Warna Tema
Edit `styles.css` line ~1-10:
```css
:root {
    --primary: #6366f1;    /* Warna utama */
    --secondary: #ec4899;  /* Warna aksen */
}
```

### Tambah Produk
1. Login admin panel
2. Menu "Produk" > "Tambah Produk"
3. Isi form > Submit

## 📱 WhatsApp Integration

Website sudah terintegrasi dengan WhatsApp untuk:
- Order confirmation
- Customer support
- Payment notification

Format pesan otomatis sudah diatur di `app.js`

## 💳 Payment Gateway

Siap integrasi dengan:
- ✅ Midtrans
- ✅ Xendit
- ✅ Doku
- ✅ Transfer Bank
- ✅ E-Wallet (DANA, OVO, GoPay)
- ✅ QRIS

Endpoint webhook: `POST /api/webhook/payment`

## 🔐 Security

- ✅ Password hashing (bcrypt)
- ✅ JWT authentication
- ✅ Role-based access
- ✅ SQL injection protection
- ✅ XSS prevention

## 📊 Database

Menggunakan SQLite dengan 6 tabel:
1. users - Data pengguna
2. products - Data produk
3. orders - Data pesanan
4. services - Data jasa joki
5. reviews - Review pelanggan
6. transactions - Data transaksi

## 🐛 Troubleshooting

### Error: Port 3000 already in use
```bash
# Ganti port
PORT=3001 npm start
```

### Error: Module not found
```bash
# Install ulang
npm install
```

### Error: Database locked
```bash
# Hapus database dan restart
rm ditzstore.db
npm start
```

### Error: Permission denied
```bash
# Jalankan dengan sudo (Linux/Mac)
sudo npm start

# Atau ubah permission
chmod +x server.js
```

## 📈 Tips Optimasi

### 1. Performa
- Gunakan CDN untuk images
- Enable caching
- Minify CSS/JS
- Compress images

### 2. SEO
- Tambahkan meta tags
- Sitemap.xml
- robots.txt
- Google Analytics

### 3. Marketing
- Integrasi social media
- Email marketing
- Promo & diskon
- Loyalty program

## 🎓 Tutorial Video

Coming soon! Subscribe channel kami di YouTube.

## 💬 Support

Ada masalah? Hubungi kami:
- 📱 WhatsApp: +62 812-3456-7890
- 📧 Email: support@ditzstore.com
- 💬 Telegram: @ditzstore
- 📸 Instagram: @ditzstore.id

## 🌟 Next Steps

Setelah instalasi selesai:

1. **Ubah password admin** di menu Settings
2. **Ganti nomor WhatsApp** di konfigurasi
3. **Tambah produk** sesuai kebutuhan
4. **Customize theme** sesuai brand
5. **Setup payment gateway**
6. **Test order flow**
7. **Go live!** 🚀

## 📚 Resources

- [Express.js Docs](https://expressjs.com/)
- [SQLite Docs](https://www.sqlite.org/docs.html)
- [Chart.js Docs](https://www.chartjs.org/docs/)
- [JWT.io](https://jwt.io/)

## ⭐ Pro Tips

1. Backup database secara rutin
2. Monitor error logs
3. Update dependencies berkala
4. Test di berbagai browser
5. Optimalkan untuk mobile
6. Gunakan HTTPS di production
7. Setup monitoring & analytics

## 🎉 Selamat!

Website toko digital Anda sudah siap!
Mulai jualan dan raih kesuksesan! 💪

---

**DiTz Store** - Made with ❤️ for Indonesian Digital Entrepreneurs

© 2024 DiTz Store. All rights reserved.
