# 🎮 DiTz Store - Full Stack Digital Store

Toko digital premium untuk akun premium, jasa joki gaming, script Free Fire, dan top up game dengan sistem full stack lengkap.

## 📋 Fitur Lengkap

### Frontend Features
- ✅ Website toko online responsive & modern
- ✅ Katalog produk dengan filter dan search
- ✅ Shopping cart dengan localStorage
- ✅ Checkout via WhatsApp
- ✅ Testimonial section
- ✅ Contact form
- ✅ Mobile-friendly design

### Admin Panel Features
- ✅ Dashboard dengan statistik real-time
- ✅ CRUD Produk (Create, Read, Update, Delete)
- ✅ Manajemen pesanan dengan status tracking
- ✅ Manajemen pelanggan
- ✅ Manajemen jasa joki
- ✅ Analytics & Reports dengan Chart.js
- ✅ Pengaturan toko & payment methods
- ✅ User authentication & authorization

### Backend API Features
- ✅ RESTful API dengan Express.js
- ✅ SQLite database
- ✅ JWT authentication
- ✅ Role-based access control (Admin & Customer)
- ✅ Password hashing dengan bcrypt
- ✅ CRUD operations untuk semua entitas
- ✅ Statistics & Analytics endpoints
- ✅ Payment webhook support
- ✅ Error handling & validation

## 🛍️ Produk yang Tersedia

### 1. Akun Premium
- Netflix Premium UHD - Rp 45.000
- Spotify Premium Family - Rp 35.000
- Disney+ Hotstar Premium - Rp 40.000
- YouTube Premium - Rp 30.000
- Canva Pro - Rp 55.000
- Viu Premium - Rp 25.000
- WeTV VIP - Rp 28.000
- iQIYI VIP - Rp 32.000
- Vidio Premier - Rp 30.000

### 2. Script Free Fire Auto Headshot
- 10% Akurasi - Rp 25.000
- 20% Akurasi - Rp 45.000
- 30% Akurasi - Rp 65.000
- 40% Akurasi - Rp 85.000
- 50% Akurasi - Rp 110.000
- 70% Akurasi - Rp 150.000
- 100% Akurasi - Rp 250.000

### 3. Jasa Joki Gaming
- Mobile Legends (Rp 50.000 - 500.000)
- Free Fire (Rp 40.000 - 400.000)
- PUBG Mobile (Rp 60.000 - 600.000)
- Brawl Stars (Rp 45.000 - 450.000)

### 4. Top Up Game
- Diamond Mobile Legends
- Diamond Free Fire
- UC PUBG Mobile
- Genesis Crystal Genshin Impact

## 🚀 Instalasi

### Prerequisites
- Node.js (v14 atau lebih baru)
- npm atau yarn
- Web browser modern

### Langkah Instalasi

1. **Clone atau Download Project**
```bash
cd ditzstore-fullstack
```

2. **Install Dependencies**
```bash
npm install
```

3. **Jalankan Server**
```bash
npm start
```

Atau untuk development dengan auto-reload:
```bash
npm run dev
```

4. **Akses Website**
- Store: http://localhost:3000/index.html
- Admin Panel: http://localhost:3000/admin.html

## 🔐 Login Admin

**Default Admin Credentials:**
- Username: `admin`
- Email: `admin@ditzstore.com`
- Password: `admin123`

⚠️ **PENTING**: Ubah password default setelah login pertama!

## 📁 Struktur File

```
ditzstore-fullstack/
├── index.html              # Halaman utama toko
├── admin.html              # Admin panel
├── styles.css              # CSS untuk toko
├── admin-styles.css        # CSS untuk admin panel
├── app.js                  # JavaScript frontend toko
├── admin-script.js         # JavaScript admin panel
├── server.js               # Backend API server
├── package.json            # Dependencies
├── README.md               # Dokumentasi
└── ditzstore.db           # SQLite database (auto-generated)
```

## 🔌 API Endpoints

### Authentication
```
POST /api/auth/register    - Register user baru
POST /api/auth/login       - Login user
```

### Products
```
GET    /api/products           - Get semua produk
GET    /api/products/:id       - Get produk by ID
POST   /api/products           - Create produk baru (Admin)
PUT    /api/products/:id       - Update produk (Admin)
DELETE /api/products/:id       - Delete produk (Admin)
```

### Orders
```
GET  /api/orders              - Get semua order (Admin)
GET  /api/orders/:orderId     - Get order by ID
POST /api/orders              - Create order baru
PUT  /api/orders/:orderId/status - Update status order (Admin)
```

### Statistics
```
GET /api/stats/dashboard      - Dashboard statistics (Admin)
GET /api/stats/categories     - Sales by category (Admin)
GET /api/stats/top-products   - Top selling products (Admin)
```

### Services
```
GET  /api/services           - Get semua jasa joki
POST /api/services           - Create jasa baru (Admin)
```

## 🎨 Customization

### Mengubah Warna Tema
Edit file `styles.css` dan `admin-styles.css`:
```css
:root {
    --primary: #6366f1;      /* Warna utama */
    --secondary: #ec4899;    /* Warna sekunder */
    --success: #10b981;      /* Warna sukses */
    --warning: #f59e0b;      /* Warna warning */
    --danger: #ef4444;       /* Warna danger */
}
```

### Mengubah Nomor WhatsApp
Edit file `app.js`:
```javascript
const whatsappNumber = '6281234567890'; // Ganti dengan nomor Anda
```

### Menambah Produk Baru
1. Login ke Admin Panel
2. Pilih menu "Produk"
3. Klik tombol "Tambah Produk"
4. Isi form dan submit

## 💳 Payment Integration

Website ini siap untuk integrasi dengan payment gateway seperti:
- Midtrans
- Xendit
- Doku
- PayPal
- Stripe

Webhook endpoint sudah tersedia di:
```
POST /api/webhook/payment
```

## 📱 Fitur Mobile

- Responsive design untuk semua ukuran layar
- Touch-friendly interface
- Mobile navigation menu
- Optimized images
- Fast loading time

## 🔒 Security Features

- Password hashing dengan bcrypt
- JWT token authentication
- Role-based access control
- SQL injection prevention
- XSS protection
- CORS enabled
- Input validation

## 📊 Database Schema

### Users Table
```sql
id, username, email, password, role, phone, created_at
```

### Products Table
```sql
id, name, category, price, stock, description, image, badge, status, sales, created_at
```

### Orders Table
```sql
id, order_id, user_id, customer_name, customer_email, customer_phone, 
products, total_amount, payment_method, status, notes, created_at
```

### Services Table
```sql
id, name, game, price_min, price_max, description, features, 
status, orders_count, created_at
```

## 🛠️ Development

### Menjalankan Development Mode
```bash
npm run dev
```

### Testing API dengan cURL
```bash
# Get all products
curl http://localhost:3000/api/products

# Login admin
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@ditzstore.com","password":"admin123"}'
```

## 📈 Performance Optimization

- Lazy loading images
- Minified CSS/JS
- Database indexing
- Cached responses
- Optimized queries
- Compressed assets

## 🐛 Troubleshooting

### Port sudah digunakan
```bash
# Ubah PORT di server.js atau gunakan environment variable
PORT=3001 npm start
```

### Database error
```bash
# Hapus database dan restart
rm ditzstore.db
npm start
```

### Module not found
```bash
# Reinstall dependencies
rm -rf node_modules package-lock.json
npm install
```

## 📝 TODO / Future Features

- [ ] Email notification system
- [ ] SMS OTP verification
- [ ] Live chat support
- [ ] Multi-language support
- [ ] Advanced search & filters
- [ ] Product reviews & ratings
- [ ] Loyalty points system
- [ ] Affiliate program
- [ ] Mobile app (React Native)
- [ ] Advanced analytics dashboard

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📞 Support

Untuk pertanyaan dan dukungan:
- WhatsApp: +62 812-3456-7890
- Email: support@ditzstore.com
- Instagram: @ditzstore.id
- Telegram: @ditzstore

## 📄 License

This project is licensed under the MIT License.

## 🙏 Credits

- Chart.js for data visualization
- Font Awesome for icons
- Unsplash for images
- Express.js for backend framework
- SQLite for database

---

**Made with ❤️ for Gamers by DiTz Store**

© 2024 DiTz Store. All rights reserved.
